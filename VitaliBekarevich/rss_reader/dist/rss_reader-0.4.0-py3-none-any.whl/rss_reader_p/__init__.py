"""
This package exports config, description_html_parser, rss, rss_exceptions modules.

config --
    the module exporting the current version of rss-reader.py utility and
    the configuration of the logging.
description_html_parser --
    the module exporting DescriptionHTMLParser class presenting a tool
    for parsing HTML text of the rss channel item description
rss --
    the module exporting RSS and RSSItem classes presenting containers
    for a rss document
rss_exceptions --
    the module exporting custom exceptions to errors which can occur
    during rss_reader.py utility running
"""