
from setuptools import setup

setup(include_package_data=True)
